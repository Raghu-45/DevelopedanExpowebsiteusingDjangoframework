from django.contrib import admin
from .models import register, News
# Register your models here.
admin.site.register(register)
admin.site.register(News)